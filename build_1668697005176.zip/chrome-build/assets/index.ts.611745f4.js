chrome.runtime.onInstalled.addListener(()=>{});console.log("RUN BACKGROUND.JS");
//# sourceMappingURL=index.ts.611745f4.js.map
